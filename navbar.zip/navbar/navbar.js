const express = require('express');
const app = express();
var router = express.Router();
var fs = require('fs'); 
const bodyParser= require('body-parser')
app.use(bodyParser.json())
app.use(bodyParser.urlencoded());

const fileUpload = require('express-fileupload');


var mongoose = require('mongoose');
mongoose.connect(// here we will connect to the database containing groups, profiles, and login);
var db = mongoose.connection;

//find current logged in user, for the relocate to their home page button.
function makeSearch(userinput) {
	//check for valid input from user before proceeding, notify user if invalid
var matchingUsers = db.users.find(//usersInput) We will search through groups and users, finding any matching results to the users search on any of its relevant parameters,
var matchingGroups = db.groups.find(//usersInput) 
	resultsList = matchingGroups.Append(matchingUsers)
	//order results list by relevance here
}

//return the results in list, 
//relocate user to a results HTML page, where the results of this ordered by relevance results will be displayed

app.listen(3019, function() { 
  console.log('listening on 3019') 
})
